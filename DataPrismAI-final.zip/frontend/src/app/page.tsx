export default function Home(){
  return (
    <main style={{padding: 40}}>
      <h1>DataPrismAI</h1>
      <p>Break your data into clear insights</p>
    </main>
  );
}
