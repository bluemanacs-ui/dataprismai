export default function WorkspacePage(){
  return (
    <main style={{padding: 40}}>
      <h1>DataPrismAI Workspace</h1>
      <p>Break your data into clear insights</p>
    </main>
  );
}
