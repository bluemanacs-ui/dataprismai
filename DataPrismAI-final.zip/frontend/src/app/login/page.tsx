export default function LoginPage(){
  return (
    <main style={{padding: 40}}>
      <h1>DataPrismAI Login</h1>
      <p>Break your data into clear insights</p>
    </main>
  );
}
