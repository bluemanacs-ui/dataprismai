export const metadata = {
  title: "DataPrismAI",
  description: "Break your data into clear insights",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
