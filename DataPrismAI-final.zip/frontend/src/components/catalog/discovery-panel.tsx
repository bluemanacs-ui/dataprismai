export function DiscoveryPanel(){ return <div>Discovery Panel</div>; }
