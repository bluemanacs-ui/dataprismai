export function CatalogSidebar(){ return <div>Catalog Sidebar</div>; }
