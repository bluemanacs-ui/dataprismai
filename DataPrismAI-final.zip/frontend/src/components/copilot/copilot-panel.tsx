export function CopilotPanel(){ return <div>Copilot Panel</div>; }
