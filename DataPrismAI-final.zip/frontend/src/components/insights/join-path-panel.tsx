export function JoinPathPanel(){ return <div>Join Path Panel</div>; }
