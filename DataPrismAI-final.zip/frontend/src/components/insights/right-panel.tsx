export function RightPanel(){ return <div>Right Panel</div>; }
