export function MessageCard(){ return <div>Message Card</div>; }
