export function Topbar(){
  return (
    <div>
      <strong>DataPrismAI</strong> — Break your data into clear insights
    </div>
  );
}
