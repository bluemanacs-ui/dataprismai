export type AskResponse = Record<string, unknown>;
