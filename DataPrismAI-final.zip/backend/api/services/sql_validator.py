# SQL validator placeholder
