# Metadata service placeholder
