# Chat service placeholder
