# Copilot service placeholder
