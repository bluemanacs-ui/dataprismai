from fastapi import FastAPI

app = FastAPI(title="DataPrismAI API")


@app.get("/health")
def health():
    return {"status": "ok", "app": "DataPrismAI"}
