# Agent state definitions placeholder
