# DataPrismAI Branding

## Product Name
DataPrismAI

## Tagline
Break your data into clear insights

## Brand Intent
A prism splits one beam of light into a clear spectrum. DataPrismAI uses the same metaphor for analytics: take raw data and transform it into understandable insights.
