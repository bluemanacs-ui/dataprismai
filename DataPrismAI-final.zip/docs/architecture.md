# DataPrismAI Architecture

Users → DataPrismAI Workspace UI → FastAPI API → Agent / Semantic / RAG / Knowledge Graph → SQL Generation → Guardrails → Trino → Data Platform → Insights / Charts / Monitoring
