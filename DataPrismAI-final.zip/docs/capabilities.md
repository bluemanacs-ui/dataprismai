# Capabilities

- Conversational BI
- Agentic analytics
- Semantic metrics
- Metadata discovery
- Knowledge graph concepts
- SQL generation
- Query guardrails
- Chart recommendation
- Insight generation
- Developer copilot
- KPI monitoring
- Autonomous insights
