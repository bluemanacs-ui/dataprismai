# DataPrismAI

**Break your data into clear insights**

DataPrismAI is a reusable conversational BI and AI data copilot platform designed to help users explore, analyze, and understand data through natural language.

![DataPrismAI Logo](docs/assets/dataprismai-logo.png)

## Tagline

**Break your data into clear insights**

## What it does

DataPrismAI combines:
- Conversational analytics
- Semantic metrics
- Metadata RAG
- Join / knowledge graph concepts
- Multi-agent orchestration
- Trino-based query execution
- KPI monitoring and autonomous insights
- Developer copilot for SQL / dbt generation

## High-level architecture

User → Next.js UI → FastAPI → Agent Orchestrator → Semantic Layer / Metadata RAG / Knowledge Graph → SQL Generator → Guardrails → Trino → Data Platform → Insight Generator → UI

## Main folders

- `backend/` FastAPI services, agents, semantic logic, metadata, monitoring
- `frontend/` Next.js product UI
- `docs/` architecture, branding, functional notes, folder tree

## Quick start

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn api.main:app --reload --host 0.0.0.0 --port 8001
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Open:
- Frontend: http://localhost:3000
- Backend health: http://localhost:8001/health

## Branding

Product name: **DataPrismAI**  
Tagline: **Break your data into clear insights**

## Notes

This package is a structured starter codebase and reference scaffold. Several advanced modules are provided as placeholders so you can incrementally plug in the full implementation.
